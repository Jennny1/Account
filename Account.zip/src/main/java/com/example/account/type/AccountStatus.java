package com.example.account.type;

public enum AccountStatus {
    IN_USE,
    UNREGISTERED
}
